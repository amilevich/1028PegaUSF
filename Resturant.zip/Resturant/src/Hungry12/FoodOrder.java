package Hungry12;

public class FoodOrder {

}
