package Hungry12;

import java.util.HashMap;
import java.util.LinkedList;
import java.util.Map;
import java.util.Scanner;

public class Restaurantmenu{
	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		//List of items to pick from to drink
		//LinkedList<String> drink = new LinkedList<String>();
		String drink1 = ("Cinnamon Brew");
		String drink2 =("Hot Chocolate");
		String drink3 =("Black Coffee");
		String drink4 =("Vanilla Iced Coffee");
		String drink5 =("Cookies n Cream");
		
		System.out.println("Choose primary food item"+ sc);
		
		System.out.println("\n");
		
System.out.println("What would you like to drink: ");
		
		String name = sc.nextLine();
//		System.out.println("Coming up" + drink1);
		
		//Scanner sa = new Scanner(System.in);
		
//		String _id;
//		String img;
//		String name;
//		String address;
//		String contactInfo;
	}

}
