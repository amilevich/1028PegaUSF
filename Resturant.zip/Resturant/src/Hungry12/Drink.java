package Hungry12;

public class Drink {

}
