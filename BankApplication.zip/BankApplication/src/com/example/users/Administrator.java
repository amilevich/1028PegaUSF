package com.example.users;

public class Administrator {

}
