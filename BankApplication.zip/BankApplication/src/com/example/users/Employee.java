package com.example.users;

public interface Employee {

}
