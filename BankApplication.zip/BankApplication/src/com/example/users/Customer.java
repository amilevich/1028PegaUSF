package com.example.users;

public interface Customer {

}
