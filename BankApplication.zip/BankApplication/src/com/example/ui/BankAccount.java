package com.example.ui;

public interface BankAccount {

	double getBalance();
	void deposit();
	void withdrawal();
	
}
