package com.example.ui;
import java.util.Scanner;
import com.example.ui.BankMenu;

public class MainActivity{
	
	
	public static void main(String[] args) {
		//int menuChoice = getMainMenu();
		//openMainMenuChoice(menuChoice);
		BankMenu.getMainMenu();
	}
	
}