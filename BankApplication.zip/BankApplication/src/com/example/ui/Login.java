package com.example.ui;

public class Login {
	
	private String accountNumber;
	private String password;
	
	public Login(String accountNumber, String password) {
		super();
		this.accountNumber = accountNumber;
		this.password = password;
	}


	public String getAccountNumber() {
		return accountNumber;
	}


	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}


	public String getPassword() {
		return password;
	}


	public void setPassword(String password) {
		this.password = password;
	}
		
	
}
