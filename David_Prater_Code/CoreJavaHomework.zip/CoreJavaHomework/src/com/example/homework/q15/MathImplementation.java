package com.example.homework.q15;

public class MathImplementation implements BasicMath {


	@Override
	public double additon(double x, double y) {

		return x + y;
	}

	@Override
	public double subtraction(double x, double y) {

		return x - y;
	}

	@Override
	public double multiplication(double x, double y) {

		return x * y;
	}

	@Override
	public double division(double x, double y) {
	
		return x / y;
	}

}
