package com.example.homework.q15;

public interface BasicMath {
	
	// Base math operations
	double additon(double x, double y);
	double subtraction(double x, double y);
	double multiplication(double x, double y);
	double division(double x, double y);


}
