package com.example.homework.q1package1;

public class VariableClass {

	private float var1;
	private float var2;
	public VariableClass() {
		super();
		this.var1 = 46.7F;
		this.var2 = 22.348F;
	}
	public float getVar1() {
		return var1;
	}
	public void setVar1(float var1) {
		this.var1 = var1;
	}
	public float getVar2() {
		return var2;
	}
	public void setVar2(float var2) {
		this.var2 = var2;
	}
	
	
	
}
