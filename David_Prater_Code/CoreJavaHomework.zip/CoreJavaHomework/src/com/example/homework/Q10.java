package com.example.homework;

public class Q10 {
	//Find the minimum of two numbers using ternary operators.
	
	public void ternaryMin(int x, int y) {
		System.out.println("");
		int min = x <= y ? x : y;
		System.out.println(min + " is the smaller integer.");
	}

}
