package com.example.homework.q11package1;

public class AccessClass {

}
