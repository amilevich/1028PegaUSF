package com.example.homework;

public class Q13 {

	// Q13. Display the triangle on the console as follows using any type of loop.
	// Do NOT use a simple group of print statements to accomplish this.
	// 0
	// 1 0
	// 1 0 1
	// 0 1 0 1

	public void printTriangle() {

		int[] binaryArray = { 0, 1, 0, 1, 0, 1, 0, 1, 0, 1 };

		for(int i = 0; i <= 4; i += 2) {
			
		}
		
	}

}
